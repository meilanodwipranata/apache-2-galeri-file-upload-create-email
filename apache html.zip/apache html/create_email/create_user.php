<?php
// Cek apakah form sudah di-submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $email = $_POST['username'];  // Ambil email yang dimasukkan
    $password = escapeshellarg($_POST['password']);  // Mengamankan input password

    // Ekstrak username dari email (ambil bagian sebelum @)
    $username = explode('@', $email)[0];  // Ambil bagian sebelum simbol '@'

    // Perintah untuk menambahkan user
    $command = "sudo adduser --disabled-password --gecos '' $username";
    
    // Perintah untuk mengubah password
    $passwordCommand = "echo '$username:$password' | sudo chpasswd";

    // Menjalankan perintah
    $output1 = shell_exec($command);
    $output2 = shell_exec($passwordCommand);

    // Tampilkan hasil output untuk debugging
    echo "<pre>";
    echo "Output adduser: $output1\n";
    echo "Output chpasswd: $output2\n";
    echo "</pre>";

    // Cek apakah perintah berhasil
    if ($output1 === null && $output2 === null) {
        echo "User $username berhasil ditambahkan!";
    } else {
        echo "Terjadi kesalahan saat menambahkan user.";
    }
}
?>