<?php
    $servername = "localhost";
    $username = "galeri";
    $pass = "123";
    $db = "galeri";

    $conn = mysqli_connect($servername,$username,$pass,$db);

?>
