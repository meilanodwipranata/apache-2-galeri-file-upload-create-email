<?php
    include("./connect.php");
    error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Aoudumber Bade - CodeMakerrs">
    <link rel="stylesheet" href="./style.css">
    <title>Image Gallery</title>
</head>
<body>
    <section class="form-container">
    <h1>Upload File Gambar Kamu</h1>
        <form action="" method="post" enctype="multipart/form-data">

            <!-- Category is now fixed to "Animals" -->
            <input type="hidden" name="category" value="Animals">

            <div class="inp">
                <fieldset>
                    <input type="file" name="image" class="file-upload" style="width:200px" required>
                </fieldset>
            </div>

            <div class="inp">
                <input type="submit" class="btn" name="upload" value="Upload Image">
            </div>
        </form>

    </section>

    <section class="gall-container">
        <div class="images">
            <?php 

                // Set default category to "Animals" if no category is selected
                $sCategory = isset($_GET["category"]) ? $_GET["category"] : 'Animals';

                $query = "SELECT * FROM gallary WHERE category='$sCategory'";

                $data = mysqli_query($conn, $query);
                $total = mysqli_num_rows($data);
                
                if ($total != 0) {
                    while ($res = mysqli_fetch_assoc($data)) {
                        echo "<div class='img-box'>";
                        echo "<img src='$res[path]' class='imgs'>";
                        echo "<div class='content-box'><p class='title'>$res[title]</p></div>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>There are No images available for the selected category.</p>";
                }
            ?>
        </div>
    </section> </body> </html> 
<script>
    setTimeout(function(){ 
        php.reload();
    }, 3000); // 3000ms = 3 
    }detik
</script>

<?php    
    if(isset($_POST["upload"])){
        $title = $_POST["title"];
        $category = "Animals";  // Fixed category value
        $image = $_FILES['image']['name'];
        $tempname = $_FILES['image']['tmp_name'];
        
        $folder = "./img/".$image;

        if(move_uploaded_file($tempname,$folder)){
            $query = "INSERT INTO gallary(title,category,path) VALUES('$title','$category','$folder')";
            $data = mysqli_query($conn,$query);
            
            if($data) {
                echo "<script>
                alert('Image Uploaded Successfully!!!');
            </script>";
            }else {
                echo "<script>
                alert('Image is not Uploaded!!!');
            </script>";
            }

        }
    }

?>
