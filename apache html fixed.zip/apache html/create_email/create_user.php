<?php
// Cek apakah form sudah di-submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $email = $_POST['username'];  
    $password = $_POST['password'];  

    // Ekstrak username dari email
    $username = explode('@', $email)[0];

    // Cek apakah user sudah ada di sistem
    $userCheck = shell_exec("id -u $username 2>&1");
    if (strpos($userCheck, "no such user") !== false) {
        // Jika user belum ada, buat user baru
        $command = "sudo adduser --disabled-password --gecos '' $username 2>&1";
        $output1 = shell_exec($command);
        
        // Tunggu sebentar agar sistem mengenali user
        sleep(1);
    } else {
        $output1 = "User $username sudah ada, langsung ubah password.";
    }

    // Set password dengan chpasswd atau passwd
    $passwordCommand = "echo '$username:$password' | sudo chpasswd 2>&1";
    $output2 = shell_exec($passwordCommand);

    // Jika chpasswd gagal, coba pakai passwd langsung
    if (strpos($output2, "error") !== false || empty($output2)) {
        $passwordCommand = "echo '$password' | sudo passwd --stdin $username 2>&1";
        $output2 = shell_exec($passwordCommand);
    }

    // Tampilkan hasil untuk debugging
    echo "<pre>";
    echo "Output adduser:\n$output1\n";
    echo "Output chpasswd:\n$output2\n";
    echo "</pre>";

    // Cek apakah ada kesalahan
    if (strpos($output1, "error") !== false || strpos($output2, "error") !== false) {
        echo "Terjadi kesalahan saat menambahkan atau mengubah password user.";
    } else {
        echo "User $username berhasil dibuat atau diperbarui!";
    }
}
?>